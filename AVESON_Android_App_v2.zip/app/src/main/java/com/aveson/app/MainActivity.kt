package com.aveson.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 18)
    private val surface = Color.rgb(16, 18, 34)
    private val surface2 = Color.rgb(23, 25, 46)
    private val purple = Color.rgb(139, 92, 246)
    private val purple2 = Color.rgb(109, 70, 210)
    private val blue = Color.rgb(56, 189, 248)
    private val white = Color.rgb(248, 249, 255)
    private val muted = Color.rgb(160, 166, 190)
    private val green = Color.rgb(74, 222, 128)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showLogin()
    }

    private fun rootLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(20), dp(22), dp(20), dp(14))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        includeFontPadding = false
    }

    private fun pill(text: String, color: Int): TextView = tv(text, 12f, color, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(6), dp(10), dp(6))
        background = rounded(surface2, 30)
    }

    private fun actionButton(label: String, action: () -> Unit): TextView = tv(label, 15f, white, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(purple, 18)
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun secondaryButton(label: String, action: () -> Unit): TextView = tv(label, 14f, white, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(13), dp(14), dp(13))
        background = rounded(surface2, 18, Color.rgb(52, 55, 82), 1)
        isClickable = true
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null, width: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(width), stroke)
    }

    private fun marginParams(h: Int = -2, top: Int = 8, bottom: Int = 8): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, if (h == -2) LinearLayout.LayoutParams.WRAP_CONTENT else dp(h)).apply {
            setMargins(0, dp(top), 0, dp(bottom))
        }

    private fun showLogin() {
        val root = rootLayout()
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg) }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(36), 0, dp(28))
        }

        content.addView(tv("AVESON", 46f, purple, true), marginParams(top = 30, bottom = 8))
        content.addView(tv("Your Music. Your Global Stage.", 20f, white, true), marginParams(top = 0, bottom = 6))
        content.addView(tv("Artist music business — one powerful app.", 14f, muted), marginParams(top = 0, bottom = 26))

        val email = EditText(this).apply {
            hint = "Email"
            setTextColor(white)
            setHintTextColor(muted)
            textSize = 15f
            singleLine = true
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(surface, 16, Color.rgb(48, 51, 76), 1)
        }
        val pass = EditText(this).apply {
            hint = "Password"
            setTextColor(white)
            setHintTextColor(muted)
            textSize = 15f
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(surface, 16, Color.rgb(48, 51, 76), 1)
        }
        content.addView(email, marginParams(56, 6, 8))
        content.addView(pass, marginParams(56, 6, 14))
        content.addView(actionButton("SIGN IN") { showDashboard(false) }, marginParams(top = 4, bottom = 8))
        content.addView(secondaryButton("DEMO ADMIN", { showDashboard(true) }), marginParams(top = 4, bottom = 18))

        val note = tv("V2 • mobile-first artist workspace", 12f, muted).apply { gravity = Gravity.CENTER }
        content.addView(note, marginParams(top = 8, bottom = 20))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showDashboard(admin: Boolean) {
        val root = rootLayout()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(tv(if (admin) "AVESON ADMIN" else "AVESON", 28f, purple, true))
        brand.addView(tv(if (admin) "Control Center" else "Artist Dashboard", 14f, muted))
        row.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(pill(if (admin) "ADMIN" else "ARTIST", if (admin) blue else purple))
        header.addView(row)
        root.addView(header, marginParams(top = 0, bottom = 8))

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(tv(if (admin) "Platform overview" else "Welcome back 👋", 21f, white, true), marginParams(top = 8, bottom = 2))
        content.addView(tv(if (admin) "Monitor releases, artists and operations." else "Your music business at a glance.", 13f, muted), marginParams(top = 0, bottom = 14))

        val metrics = arrayOf(
            "TOTAL STREAMS" to "128,540",
            "EARNINGS" to "$1,284.60",
            "ACTIVE RELEASES" to "12",
            "TOP COUNTRY" to "Uzbekistan"
        )
        metrics.forEachIndexed { index, pair ->
            val card = metricCard(pair.first, pair.second, index)
            content.addView(card, marginParams(top = 5, bottom = 7))
        }

        val activity = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(surface, 20)
        }
        activity.addView(tv("Recent activity", 16f, white, true))
        activity.addView(tv("Release review queue", 13f, muted), marginParams(top = 8, bottom = 2))
        activity.addView(tv("3 releases waiting for review", 14f, white))
        val status = tv("●  ON TRACK", 11f, green, true).apply { setPadding(0, dp(10), 0, 0) }
        activity.addView(status)
        content.addView(activity, marginParams(top = 12, bottom = 18))

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        nav.addView(navItem("HOME") { showDashboard(admin) }, navParams())
        nav.addView(navItem(if (admin) "QUEUE" else "UPLOAD") { if (admin) showQueue() else showUpload() }, navParams())
        nav.addView(navItem("PROFILE") { showProfile(admin) }, navParams())
        root.addView(nav)
        setContentView(root)
    }

    private fun navParams() = LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }

    private fun navItem(label: String, action: () -> Unit): TextView = secondaryButton(label, action).apply { textSize = 12f }

    private fun metricCard(title: String, value: String, index: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(15), dp(17), dp(15))
        background = rounded(surface, 20)
        val top = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(tv(title, 11f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(tv(if (index == 0) "+12.4%" else "LIVE", 10f, if (index == 0) green else blue, true))
        addView(top)
        addView(tv(value, 26f, white, true), marginParams(top = 8, bottom = 0))
    }

    private fun showUpload() {
        val root = rootLayout()
        root.addView(tv("AVESON", 28f, purple, true), marginParams(top = 0, bottom = 2))
        root.addView(tv("Upload Music", 21f, white, true), marginParams(top = 4, bottom = 4))
        root.addView(tv("Prepare your next global release.", 13f, muted), marginParams(top = 0, bottom = 16))

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val fields = listOf("Release title", "Artist name", "Genre", "Release date")
        fields.forEach { hint ->
            val e = EditText(this).apply {
                this.hint = hint
                setTextColor(white); setHintTextColor(muted); textSize = 15f; singleLine = true
                setPadding(dp(16), 0, dp(16), 0); background = rounded(surface, 16, Color.rgb(48,51,76), 1)
            }
            content.addView(e, marginParams(56, 5, 7))
        }
        content.addView(actionButton("SELECT AUDIO FILE") { toast("Audio picker — next build") }, marginParams(top = 8, bottom = 8))
        content.addView(secondaryButton("SELECT COVER ART") { toast("Cover picker — next build") }, marginParams(top = 4, bottom = 12))
        content.addView(tv("Accepted target: WAV/MP3 + JPG/PNG cover", 12f, muted), marginParams(top = 0, bottom = 16))
        content.addView(actionButton("SUBMIT FOR REVIEW") { toast("Release submitted — demo mode") }, marginParams(top = 0, bottom = 20))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(secondaryButton("← BACK TO DASHBOARD") { showDashboard(false) }, marginParams(top = 8, bottom = 0))
        setContentView(root)
    }

    private fun showQueue() {
        val root = rootLayout()
        root.addView(tv("AVESON ADMIN", 28f, purple, true), marginParams(top = 0, bottom = 2))
        root.addView(tv("Release Queue", 21f, white, true), marginParams(top = 4, bottom = 4))
        root.addView(tv("Review incoming artist releases.", 13f, muted), marginParams(top = 0, bottom = 16))

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf("Midnight Echoes" to "Pending Review", "Yurak Sadosi" to "Metadata Check", "Global Lights" to "Pending Review").forEach { item ->
            val c = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(surface, 20)
            }
            val r = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            r.addView(tv(item.first, 16f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(pill(item.second, if (item.second == "Pending Review") blue else purple))
            c.addView(r)
            c.addView(tv("Artist release • audio + cover", 12f, muted), marginParams(top = 8, bottom = 0))
            content.addView(c, marginParams(top = 5, bottom = 7))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(secondaryButton("← BACK TO ADMIN") { showDashboard(true) }, marginParams(top = 8, bottom = 0))
        setContentView(root)
    }

    private fun showProfile(admin: Boolean) {
        val root = rootLayout()
        root.addView(tv("AVESON", 28f, purple, true), marginParams(top = 0, bottom = 2))
        root.addView(tv("Profile", 21f, white, true), marginParams(top = 4, bottom = 4))
        root.addView(tv(if (admin) "Administrator" else "Artist account", 14f, muted), marginParams(top = 0, bottom = 18))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = rounded(surface, 20)
        }
        card.addView(tv(if (admin) "AVESON Operations" else "Demo Artist", 18f, white, true))
        card.addView(tv(if (admin) "Admin access enabled" else "Global artist workspace", 13f, muted), marginParams(top = 8, bottom = 0))
        root.addView(card, marginParams(top = 4, bottom = 18))
        root.addView(actionButton("LOG OUT") { showLogin() }, marginParams(top = 0, bottom = 8))
        root.addView(secondaryButton("← BACK") { showDashboard(admin) }, marginParams(top = 0, bottom = 0))
        setContentView(root)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
